
import json, gzip
from scoring import compute_emergence_score
from utils import apply_rule

def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)

def run_sim(rule_path, init_path, steps):
    rule = load_json(rule_path)
    tape = load_json(init_path)["tape"]
    history = [tape]

    for _ in range(steps):
        tape = apply_rule(tape, rule)
        history.append(tape)

    score = compute_emergence_score(history)
    out = {
        "rule": rule_path,
        "init": init_path,
        "score": score,
        "history": history
    }
    with open(f'results/{rule_path.split("/")[-1].replace(".json", "")}_output.json', 'w') as f:
        json.dump(out, f)

# Example usage:
# run_sim('rulesets/rule_0713.json', 'initial_states/central_seed.json', 1000)
