# Symbolic Emergence Simulation Toolkit

This repository supports the simulations presented in the paper:  
**"A Compression-Based Principle of Existence"**.

We simulate symbolic universes—bitstrings, automata, and rewriting systems—and evaluate their emergence potential using compressibility and structural persistence metrics.

...

(Copy full README content from previous message if needed.)
